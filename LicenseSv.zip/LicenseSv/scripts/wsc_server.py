import sys
import os

import websockets
from websockets import WebSocketServerProtocol
import asyncio

from threading import Thread
import threading
import time

import cfg.Template as API

class Wsc_Server:
    def __init__(self, ip, port):
        self.clients = set()
        self.list_clinets = []
        self.loop = asyncio.get_event_loop()
        self._client_timeout = 1
        self._wake_up_task = None
        self.ip = ip
        self.port = port
        self.mess = ''
        self.full_client = 10000
        self.list_clinets_provider = []
        self.authen: object
        self.buffer_dict_id_index_client = {}

    def Listen(self):
        print("listening on {}:{}".format(self.ip, self.port))
        wsc = websockets.serve(self.connect_client, self.ip, self.port)
        asyncio.ensure_future(wsc)

        try:
            self.loop.run_forever()
        except KeyboardInterrupt:
            print('Exit !')

    async def connect_client(self, client: WebSocketServerProtocol, path):

        self.clients.add(client)
        self.list_clinets.append(client.remote_address)
        print(' > new client connected from {}:{}'.format(*client.remote_address))
        print(' > số lượng client kết nối : {} \n list client đang kết nối : {} '.format(len(self.list_clinets), self.list_clinets))

        buffer_dict = {
            client.remote_address: {
                'index': None,
                'status': 'null',
                'id_device': 'null',
                'img_info': 'null'
            }
        }
        self.buffer_dict_id_index_client.update(buffer_dict)

        if len(self.list_clinets) > self.full_client:
            print('full client ')
            await self.DisconnectClient(client)
        else:
            AuthenTask = asyncio.ensure_future(self.SendRequestAuthen(client))

            try:
                pass
                # await asyncio.ensure_future(self.handle_messages_input(client, authen))
            except:
                # keep_alive_task.cancel()
                AuthenTask.cancel()
                await self.DisconnectClient(client)
                print('> disconnect_client connect_client')
            
    async def DisconnectClient(self, client):
        try :
            self.clients.remove(client)
            self.list_clinets.remove(client.remote_address)
        except :
            pass

    async def SendRequestAuthen(self, client):
        try:
            for CountTime in range(2):
                await client.send(API.api_request_id)
                await asyncio.sleep(1)

            # sau 5 lần request
            # await client.send(API.api_request_close)
            # disconnect_client

        except:
            await self.DisconnectClient(client)
            print("> stop send authen check ")