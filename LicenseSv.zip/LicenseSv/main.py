from scripts.wsc_server import Wsc_Server





if __name__ == '__main__':
   wsc = Wsc_Server('0.0.0.0', 8443)
   wsc.Listen();   