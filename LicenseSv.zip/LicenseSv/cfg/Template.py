api_request_id = '{"state":"authen","type":"request","value":"get_id"}'
api_request_close = '{"state":"authen","type":"notification","value":"close"}'